create definer = root@localhost trigger tr_userLog
    after insert
    on test
    for each row
begin
		insert  into userinfo values(null,'修改用户',now());
end;

